public class Main {
    public static void main(String[] args) {
        Person person = new Person("Marwan", "Smouha",
                "01142223334", "MAROO@gmail.com");

        Student student = new Student("7amoda", "GLEEM", "01222222222",
                "mohamed@gmail.com", Student.JUNIOR);

        Employee employee = new Employee("hossam", "Smouha", "01199999999",
                "tarek@gmail.com", 936, 10000);

        Faculty faculty = new Faculty("Wael", "Zizinia", "01000000000",
                "ali@gmail.com", 502, 50000, "4pm to 6pm", "Professor");

        Staff staff = new Staff("Maroo", "Cairo", "0111111111",
                "marwan@gmail.com", 110, 65000, "Executive Assistant");


        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
        System.out.println(faculty.toString());
        System.out.println(staff.toString());
    }
}